from flask import Flask, render_template, request
import mysql.connector

app = Flask(__name__)


@app.route('/')
@app.route('/page_1.html')
def home_page():
    return render_template("page_1.html")


@app.route('/HTML.html', methods=['POST', 'GET'])
def database():
    data = connector()
    if request.method == 'GET':
        return render_template("HTML.html", data=data)


def connector():
    conn = mysql.connector.connect(
        host="hannl-hlo-bioinformatica-mysqlsrv.mysql.database.azure.com",
        user="flezi@hannl-hlo-bioinformatica-mysqlsrv",
        db="flezi",
        passwd="Tutorgroep4HYL")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM result")
    data = cursor.fetchall()
    conn.close()
    cursor.close()
    return data


# def sql_query():
#    conn = mysql.connector.connect(
#        host="hannl-hlo-bioinformatica-mysqlsrv.mysql.database.azure.com",
#        user="flezi@hannl-hlo-bioinformatica-mysqlsrv",
#        db="flezi",
#        passwd="Tutorgroep4HYL")
#    cur = conn.cursor()
#    cur.execute("SELECT header FROM blast")
#    head = cur.fetchall()
#    conn.close()
#    cur.close()
#    return head


if __name__ == '__main__':
    app.run(debug=True)

# cursor.execute("SELECT header FROM blast")
# s = "<table style='border:1px solid black'>"
# for row in cursor:
#    s = s + "<tr>"
# for x in row:
#    s = s + "<td>" + str(x) + "</td>"
# s = s + "</tr>"
# conn.close()

# @app.route('/')
# @app.route('/home')
# def home():
#    return "<html><body>" + s + "</body></html>"

# data = request.form
#    Blast_ID = data['Blast_ID']
#    Header = data['Header']
#    Sequentie = data['Sequentie']
#    Read_fw_or_rv = data['Read_fw_or_rv']

# data = request.form
# cursor = mysql.connection.cursor()
# result = cursor.execute
# ("SELECT Blast_ID, Header, Sequentie, Read_fw_or_rv FROM blast")
# if result > 0:
#    data = cursor.fetchall()
# cursor.close()

# db = yaml.load(open('db.yaml'))
# app.config['MYSQL_HOST'] = db['mysql_host']
# app.config['MYSQL_USER'] = db['mysql_user']
# app.config['MYSQL_DB'] = db['mysql_db']
# app.config['MYSQL_PASSWORD'] = db['mysql_password']

# conn = mysql.connector.connect(
#    host="hannl-hlo-bioinformatica-mysqlsrv.mysql.database.azure.com",
#    user="flezi@hannl-hlo-bioinformatica-mysqlsrv",
#    db="flezi",
#    passwd="Tutorgroep4HYL")
